package common;

public interface ChatIF {
    public abstract void display(String message);
}
